 $(document).ready(function () {
                var height = window.innerHeight;
                var width = window.innerWidth;
                //alert(width);

	
	$(".navbar-toggle").click(function(){
		var effect = 'slide';

    // Set the options for the effect type chosen
    var options = { direction: 'left' };

    // Set the duration (default: 400 milliseconds)
    var duration = 500;
		$("#navbar").toggle(effect, options, duration);
		
		$('html').toggleClass('killscroll');
		
		})
		


});	
